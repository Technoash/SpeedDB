function createError(name, message){
	var error = function(message) {
	  this.name = 'MyError';
	  this.message = message || 'Default Message';
	}
	error.prototype = Object.create(Error.prototype);
	error.prototype.constructor = error;
	return error;
}

function queryToolsetupFn($scope, apiFactory){
	$scope.setup = queryToolSetup;
	return new Promise(function(res, rej){
		if(!queryToolSetup){
			$scope.setup = {
				monthNames: monthNames,
				years: []
			};
			apiFactory.get('/api/query/setup')
			.then(function(setup){
				$scope.setup.laws = setup.data.laws;
				$scope.setup.cameras = setup.data.cameras;
				res();
			});
		    var currentyear = new Date().getFullYear();
		    for(var i = -20; i < 21; i++){
		    	$scope.setup.years.push(currentyear+i);
		    }
		    queryToolSetup = $scope.setup;
		}
	})
}

var NoQuery = createError("NoQuery");

var isPosInt = function(str) {
	var n = Math.floor(Number(str));
	return String(n) === str && n >= 0;
}

var objSize = function(obj) {
	var size = 0, key;
	for (key in obj) {
		if (obj.hasOwnProperty(key)) size++;
	}
	return size;
};

var monthNames = [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ];

var queryToolSetup = false;

angular.module('speed', ['ngRoute', 'ui.select', 'ngSanitize'])
.config(function($routeProvider, $locationProvider) {
	$routeProvider
	  .when('/query/new', {
		templateUrl: 'templates/query_tool.html',
		controller: 'QueryToolCtrl',
		controllerAs: 'queryTool'
	  })
	  .when('/query/edit/:id', {
		templateUrl: 'templates/query_tool.html',
		controller: 'QueryToolCtrl',
		controllerAs: 'queryTool',
		editSearch: true
	  })
	  .when('/search', {
		templateUrl: 'templates/search.html',
		controller: 'SearchCtrl',
		controllerAs: 'search'
	  })
	  .when('/graph', {
		templateUrl: 'templates/graph.html',
		controller: 'GraphCtrl',
		controllerAs: 'graph'
	  })
	$locationProvider.html5Mode(false).hashPrefix('!');
})

.controller('MainCtrl',function MainCtrl($scope, $route, $routeParams, $location, pageTitle) {
	$scope.pageTitle = pageTitle;
	this.$route = $route;
	this.$location = $location;
	this.$routeParams = $routeParams;
})


.controller('QueryToolCtrl', function QueryToolCtrl($scope, $routeParams, $http, $location, apiFactory, dataSetStore, $route, $routeParams, pageTitle) {
	$scope.editSearch = $route.current.$$route.editSearch;
	$scope.editSearchId = $routeParams.id;

	if($scope.editSearch){
		pageTitle.setTitle("Edit Query");
		$scope.query = dataSetStore.getModel($scope.editSearchId);
		if(!$scope.query) $location.path('query/new');
	}else{
		pageTitle.setTitle("New Query");
		$scope.query = dataSetStore.getSearchModel();

	}
	
	$scope.reset_query = function(){
		$scope.query = {
			fine_from: "",
			fine_to: "",
			speed_filter: {
		    	'10-': false,
		    	'10+': false,
		    	'20+': false,
		    	'30+': false,
		    	'45+': false
		    },
			offence_type: "none",
			laws: [],
			month: {
		    	to: {
					year: "",
		    		month: ""
		    	},
		    	from: {
		    		year: "",
		    		month: ""
		    	}
		    },
		    cameras: []
		};
	}

	if(!$scope.query){
		$scope.reset_query();
	}
	queryToolsetupFn($scope, apiFactory);
	/*
	$scope.setup = queryToolSetup;
	if(!queryToolSetup){
		$scope.setup = {
			monthNames: monthNames,
			years: []
		};
		apiFactory.get('/api/query/setup')
		.then(function(setup){
			$scope.setup.laws = setup.data.laws;
			$scope.setup.cameras = setup.data.cameras;
		});
	    var currentyear = new Date().getFullYear();
	    for(var i = -20; i < 21; i++){
	    	$scope.setup.years.push(currentyear+i);
	    }
	    queryToolSetup = $scope.setup;
	}
	*/
	$scope.isPosInt = isPosInt;

    $scope.offence_type_change = function(type){
    	if(type != 'red') return;
    	$scope.query.speed_filter = {
	    	'10-': false,
	    	'10+': false,
	    	'20+': false,
	    	'30+': false,
	    	'45+': false
	    };
    }

    $scope.add_law = function(){
    	$scope.query.laws.push({ value: $scope.setup.laws[0] });
    }
    $scope.remove_law = function(i){
    	$scope.query.laws.splice(i, 1);
    }

    $scope.month_change = function(to, month){
    	var target = $scope.query.month[(to?"to":"from")][(month?"month":"year")];
    	if(target == ""){
    		$scope.query.month[(to?"to":"from")][(month?"year":"month")] = "";
    	}else{
    		if($scope.query.month[(to?"to":"from")][(month?"year":"month")] == "")
			$scope.query.month[(to?"to":"from")][(month?"year":"month")] = ""+(month?new Date().getFullYear():new Date().getMonth()+1);
    	}
    }
    
    $scope.add_camera = function(){
    	$scope.query.cameras.push({ value: $scope.setup.cameras[0] });
    }
    $scope.remove_camera = function(i){
    	$scope.query.cameras.splice(i, 1);
    }

	$scope.add_to_graph = function(){
		dataSetStore.addDataSet($scope.query);
		$location.path('graph');
	}
	$scope.update_graph_query = function(){
		dataSetStore.updateDataSet($scope.editSearchId, $scope.query);
		$location.path('graph');
	}
	$scope.search = function(){
    	dataSetStore.updateSearchDataSet($scope.query);
		$location.path('search');
    }
})



.controller('SearchCtrl', function SearchCtrl($scope, $routeParams, $http, dataSetStore, apiFactory, pageTitle) {
	pageTitle.setTitle("Search Results");
	$scope.responded = false;
	$scope.query = dataSetStore.getSearchQuery();
	$scope.results = [];

	if($scope.query){
		apiFactory.post('/api/search', $scope.query)
		.then(function(result){
			$scope.results = result.data;
			$scope.responded = true;
		});
	}

	$scope.formatMonth = function(da){
		var month = new Date(da);
		
		return monthNames[month.getMonth()] + " " + month.getFullYear();

	}
})


.controller('GraphCtrl', function GraphCtrl($scope, $routeParams, $http, apiFactory, dataSetStore, $location, pageTitle) {
	pageTitle.setTitle("Graph Creator");
	queryToolsetupFn($scope, apiFactory);
	function refreshQueries(){
		$scope.queries = dataSetStore.getQueries();
		$scope.n_queries = objSize($scope.queries);
		$scope.display_viewed = null;
	}
	refreshQueries();
	
	$scope.set_display_query = function(id){
		if($scope.display_viewed == id) return $scope.display_viewed = null;
		$scope.display_viewed = id;
	}
	$scope.edit_query = function(id){
		$location.path('/query/edit/'+id);
	}
	$scope.delete_query = function(id){
		dataSetStore.deleteDataSet(id);
		refreshQueries();
	}

	$scope.submit_graph = function(){
		apiFactory.post('/api/graph', {queries: $scope.queries, rangeName: "total_fine_value/cases", domainName: "camera", domain: ['7161', '7160', '7162']})
		.then(function(data){
			console.log(data.data);
			var ctx = document.getElementById('myChart').getContext('2d');
			var data = data.data;

			var labels = [];
			for(var i = 0; i < data.domain.length; i++){
				for(var a = 0; a < $scope.setup.cameras.length; a++){
					if(data.domain[i] == $scope.setup.cameras[a].location_code) {
						labels.push($scope.setup.cameras[a].location_description+" "+$scope.setup.cameras[a].type);
						break;
					}
				}
			}

			var dataobj = {
				labels: labels,
				datasets: []
			}

			for(var dataSetId in data.dataSets){
				if (!data.dataSets.hasOwnProperty(dataSetId)) continue;
				var queryName = dataSetId;
				dataobj.datasets.push({label: queryName, data: []});
				for(var dataSetColId in data.dataSets[dataSetId]){
					if (!data.dataSets[dataSetId].hasOwnProperty(dataSetColId)) continue;
					dataobj.datasets[dataobj.datasets.length-1].data[dataSetColId.split("_")[1]] = data.dataSets[dataSetId][dataSetColId];
				}
			}

			console.log(dataobj);
			var chart = new Chart(ctx, {
			    type: 'bar',
			    data: dataobj,
			    options: {
					scales: {
						xAxes: [{
							stacked: false,
							beginAtZero: true,
							scaleLabel: {
								labelString: 'Camera'
							},
							ticks: {
								stepSize: 1,
								min: 0,
								autoSkip: false
							}
						}]
					}
				}
			});
		})
	}
})


.factory('apiFactory', function ($http, $q){
	var factory = {};
	factory.get = function(path){
		return $http.get(path);
	}
	factory.post = function(path, data){
		return $http.post(path, data);
	}

	return factory;
})


.factory('dataSetStore', function() {
	function generateQueryFromModel(model){
		var query = {
			month_from: null,
			month_to: null,
			laws: [],
			cameras: [],
			excess_speeds: [],
			red_light: null,
			individual_fine_value_from: null,
			individual_fine_value_to: null
		};
		if(model.month.from.month != "" && model.month.from.year != ""){
			query.month_from = {
				year: parseInt(model.month.from.year),
				month: parseInt(model.month.from.month)
			}
		}
		if(model.month.to.month != "" && model.month.to.year != ""){
			query.month_to = {
				year: parseInt(model.month.to.year),
				month: parseInt(model.month.to.month)
			}
		}
		if(model.offence_type == "speed"){
			query.red_light = false;
		}
		if(model.offence_type == "red"){
			query.red_light = true;
		}
		if(isPosInt(model.fine_from)){
			query.individual_fine_value_from = parseInt(model.fine_from);
		}
		if(isPosInt(model.fine_to)){
			query.individual_fine_value_to = parseInt(model.fine_to);
		}
		for(var i = 0; i < model.laws.length; i++){
			query.laws.push(model.laws[i].value);
		}
		for(var i = 0; i < model.cameras.length; i++){
			query.cameras.push(model.cameras[i].value.location_code);
		}
		for (var k in model.speed_filter){
			if (!model.speed_filter.hasOwnProperty(k)) continue;
			if(model.speed_filter[k]) query.excess_speeds.push(k);
		}
		return query;
	}

	var savedModels = {};
	var savedQueries = {};
	var savedSearchModel = null;
	var savedSearchQuery = null;
	var id = 0;
	function addDataSet(model) {
		id++;
		deleteDataSet(id);
		savedQueries[id] = generateQueryFromModel(model);
		savedModels[id] = model;
	}
	function updateDataSet(id, model) {
		savedQueries[id] = generateQueryFromModel(model);
		savedModels[id] = model;
	}
	function deleteDataSet(id) {
		delete savedModels[id];
		delete savedQueries[id];
	}
	function getQueries() {
		return savedQueries;
	}
	function getModel(id) {
		return savedModels[id];
	}
	function getQuery(id) {
		return savedQueries[id];
	}
	function updateSearchDataSet(model) {
		savedSearchQuery = generateQueryFromModel(model);
		savedSearchModel = model;
	}
	function getSearchQuery() {
		return savedSearchQuery;
	}
	function getSearchModel() {
		return savedSearchModel;
	}
	return {
		addDataSet: addDataSet,
		getQueries: getQueries,
		getModel: getModel,
		deleteDataSet: deleteDataSet,
		getQuery: getQuery,
		updateSearchDataSet: updateSearchDataSet,
		getSearchQuery: getSearchQuery,
		getSearchModel: getSearchModel,
		updateDataSet: updateDataSet
	}
})


.directive('querydisplay', function () {
return {
    restrict: 'E',
    scope: {query : '=', hide: '=?'},
    templateUrl: '/templates/querydisplay.html',
    controller: function ($scope, $attrs) {
    	$scope.hidden = true;
    	$scope.size = 11;
    	$scope.size_increase = function(){
    		$scope.size++;
    	}
    	$scope.size_decrease = function(){
    		$scope.size--;
    	}
    	$scope.toggle = function(){
    		$scope.hidden = !$scope.hidden;
    	}
    }
}
})
.factory('pageTitle', function() {
	var title = 'default';
	return {
		title: function() {
			return title;
		},
		setTitle: function(newTitle) {
			console.log(newTitle);
			title = newTitle;
		}
	};
});